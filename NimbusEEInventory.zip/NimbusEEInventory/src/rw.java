import java.io.*;
import java.util.Objects;
import java.util.Scanner;

public class rw { // reader / writer class
    public static File file = new File("inventoryRaw.txt");

    public static String read(String type) {
        Scanner filesc;
        try {
            filesc = new Scanner(file);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        if (Objects.equals(type, "next")) {
            return filesc.next();
        }
        else if (Objects.equals(type, "nextLine")) {
            return filesc.nextLine();
        }
        filesc.close();
        return "";

    }
    public static void write (String writerInput) {
        FileWriter fw;
        try {
            fw = new FileWriter(file);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {
            fw.write(writerInput);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {
            fw.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    private static int getIndexOf(String searchTerm) {
        int index = 0;
        while (!Objects.equals(read("next"), searchTerm)) {
            index++;
        }
        return index;
    }
}
