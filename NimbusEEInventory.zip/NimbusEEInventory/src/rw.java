import java.io.*;
import java.util.Objects;
import java.util.Scanner;
import java.util.StringTokenizer;

public class rw { // reader / writer class
    public static File file = new File("inventoryRaw.txt");

    public static String read(String type) {
        Scanner filesc;
        try {
            filesc = new Scanner(file);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        if (Objects.equals(type, "next")) {
            return filesc.next();
        }
        else if (Objects.equals(type, "nextLine")) {
            return filesc.nextLine();
        }
        else if (Objects.equals(type, "hasNext")) {
            if (filesc.hasNext()) {
                return "true";
            }
            else {
                return "false";
            }
        }
        else if (Objects.equals(type, "length")) {
            StringTokenizer st = new StringTokenizer(file.toString());
            return String.valueOf(st.countTokens());
        }
        filesc.close();
        return "";

    }
    public static void write (String writerInput) {
        FileWriter fw;
        try {
            fw = new FileWriter(file);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {

            fw.write(writerInput);

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {
            fw.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public static int getIndexOf(String searchTerm) {
        int index = 0;
        while (!Objects.equals(read("next"), searchTerm) && Objects.equals(read("hasNext"), "true")) {
            index++;
            read("next");
        }
        if (index >= Integer.parseInt(read("length"))) {
            return -1;
        }
        return index;
    }
}
