import java.util.Scanner;
public class review {
    public static Scanner console = new Scanner(System.in);
    public static void takeInput() {
        System.out.println("gimme part number: ");
        displayPage(console.next());
        console.close();
    }
    public static void displayPage(String input) {
        renderman.run(input);
        userPrompt();
    }
    private static void userPrompt() {
        System.out.println("W to enter a new part number, or E to exit: ");
        char selection = console.next().charAt(0);
        switch (selection) {
            case 'w':
                takeInput();
            case 'e':
                init.menu(false);
        }
    }
}
