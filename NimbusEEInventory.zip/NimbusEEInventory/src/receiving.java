public class receiving {
    public static void receive() {
        // Get Part Number

        // Validate P/N, handle not found

        // if found, display a page that displays info and takes input

        // Update quantity in raw file

        
    }

}
