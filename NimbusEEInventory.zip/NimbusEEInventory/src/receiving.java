import java.util.Scanner;

public class receiving {
    public static void receive() {

        // Get Part Number
        char inputType = 'n';
        String input = takeInput(inputType);

        // Validate P/N, handle not found
        validate(input);

        // Call menu function
        init.menu(init.firstOpen);
    }
    private static String takeInput(char inputType) {
        Scanner console = new Scanner(System.in);
        if (inputType == 'n') {         // Accept part number
            System.out.println("Enter a Nimbus part number:  ");
            return console.nextLine();

        }
        else if (inputType == 'q') {    // Accept quantity
            System.out.println("Enter the quantity received: ");
            quantityUpdater(console.nextInt());
        }
        else if (inputType == 'c') {
            System.out.println("W to update another part, or E to exit: ");
            char selection = console.next().charAt(0);
            if (selection == 'w') {
                takeInput('n');
            }
            if (selection != 'e') {
                System.out.println("Invalid selection!");
                takeInput('c');
            }
        }
        else {
            System.out.println("Invalid input type [testing only]");
            return "Error, closing.";
        }
    }
    private static void validate(String input) {
        rw.getIndexOf(input);
    }

    private static void quantityUpdater(int quantityAdded) {

        System.out.println("Quantity added successfully.");
    }

}
