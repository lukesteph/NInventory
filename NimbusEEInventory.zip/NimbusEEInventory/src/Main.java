public class Main {
    public static void main(String[] args) {

        // Welcome User + initialization
        init initializer = new init();
        initializer.init();

        // Find Product, display Product Page

        // Handle User Selection
            // View

            // Update

            // Order
                // Web Redirect


        // Exit Handler


    }
}
