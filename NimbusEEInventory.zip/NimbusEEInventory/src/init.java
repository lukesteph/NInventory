import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;

public class init {
    public static boolean firstOpen = true;
    public static char previousPage = ' ';
    public static void init(){
        welcome();
        menu(firstOpen);
    }



    private static void welcome() {
        System.out.println("Welcome to NInventory");

    }
    public static void menu(boolean firstOpen) {
        Scanner console = new Scanner(System.in);
        if (firstOpen) {
            System.out.println("a) Receiving \n b) Review \n c) Order Parts \n d) Exit");
            System.out.println("What would you like to do? Enter the letter that corresponds to your choice: ");

            char selection = console.next().charAt(0);
            previousPage = selection;
            firstOpen = false;

            redirect(selection);
        }
        else {
            System.out.println("a) Receiving \n b) Review \n c) Order Parts \n d) Exit \n e) Return to Previous");
            System.out.println("What would you like to do? Enter the letter that corresponds to your choice: ");

            char selection = console.next().charAt(0);
            previousPage = selection;

            redirect(selection);
        }
    }
    private static void redirect(char selection) {
        switch (selection) {
            case 'a':
                // Receiving
            case 'b':
                // Review
            case 'c':
                // Order
            case 'd':
                // Exit
            case 'e':
                redirect(previousPage);
        }
    }
}
