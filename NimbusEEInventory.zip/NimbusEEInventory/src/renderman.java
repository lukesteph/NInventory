public class renderman {
    public static void run(String input) {
        String[] infoArray = loadDetails(input);
        displayPage(infoArray);
    }
    private static String[] loadDetails(String input) {
        String zero = rw.read("next");
        String one = rw.read("next");
        String two = rw.read("next");
        String[] infoArray = {zero, one, two};

        return infoArray;
    }
    public static void displayPage(String[] infoArray) {


        System.out.print("\033[H\033[2J");
        System.out.flush();
        System.out.println("Nimbus Part #" + infoArray[0]);
        System.out.println("\n \n");
        System.out.println("Current quantity:" + infoArray[1]);
        System.out.println("\n \n");
        System.out.println("Link: " + infoArray[2]);
        System.out.println("\n \n");
    }
}
